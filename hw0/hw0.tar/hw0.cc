#include <iostream>
using namespace std;
int main()
{
  cout << "2 - because the first one passed out drunk!\n";
  return 0;
}
